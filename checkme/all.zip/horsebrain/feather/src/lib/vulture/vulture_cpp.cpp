#include "window.hpp"

int main(int argc, char **argv)
{
    feather::vulkan::Window* window = new feather::vulkan::Window();
    return 0;
}; 
