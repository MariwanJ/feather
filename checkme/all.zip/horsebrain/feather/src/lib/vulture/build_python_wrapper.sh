swig -python -c++ vulture.i
